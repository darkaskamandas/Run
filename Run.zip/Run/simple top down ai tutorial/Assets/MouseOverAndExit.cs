﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseOverAndExit : MonoBehaviour
{
    public GameObject objectName;

    private void OnMouseOver()
    {
        objectName.SetActive(true);
    }

    private void OnMouseExit()
    {
        objectName.SetActive(false);
    }
}
